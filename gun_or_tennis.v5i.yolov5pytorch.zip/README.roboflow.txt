
gun_or_tennis - v5 2021-09-25 11:30am
==============================

This dataset was exported via roboflow.ai on September 25, 2021 at 4:31 AM GMT

It includes 66 images.
Gun are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Resize to 416x416 (Stretch)

The following augmentation was applied to create 3 versions of each source image:
* Salt and pepper noise was applied to 5 percent of pixels


