
gun_or_tennis - v1 2021-09-25 11:10am
==============================

This dataset was exported via roboflow.ai on September 25, 2021 at 4:12 AM GMT

It includes 65 images.
Gun are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

The following augmentation was applied to create 3 versions of each source image:

The following transformations were applied to the bounding boxes of each image:
* Random rotation of between -15 and +15 degrees


