
gun_or_tennis - v3 2021-09-25 11:23am
==============================

This dataset was exported via roboflow.ai on September 25, 2021 at 4:25 AM GMT

It includes 64 images.
Gun are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Resize to 416x416 (Stretch)

The following augmentation was applied to create 3 versions of each source image:

The following transformations were applied to the bounding boxes of each image:
* Random Gaussian blur of between 0 and 10 pixels


